import CartPage from "../presentation/CartPage"


const CartPageContainer = () => {
    return (
        <CartPage />
    )
}

export default CartPageContainer;