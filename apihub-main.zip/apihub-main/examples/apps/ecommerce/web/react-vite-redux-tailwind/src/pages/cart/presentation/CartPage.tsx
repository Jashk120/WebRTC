import CartContainer from "../../../components/widgets/cart/container/CartContainer";


const CartPage = () => {
    return (
        <div className="px-2 py-4 lg:px-10">
            <CartContainer />
        </div>
    )
}

export default CartPage;