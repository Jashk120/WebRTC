import HomePage from "../presentation/HomePage";


const HomePageContainer = () => {
    return (
        <>
            <HomePage />
        </>
    )
}

export default HomePageContainer;